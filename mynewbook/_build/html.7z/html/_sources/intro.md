# Introducción

¡Hola!,

En Celsia nos encanta acompañarte en tu meta de ser más eficiente. Por eso, te presentamos tu informe de gestión de energía para Carvajal, correspondiente al trimestre agosto a octubre de 2023.


![alt text](https://www.celsia.com/wp-content/uploads/2021/11/Celsia-Horizonal-Eslogan_Jpg.jpg)
